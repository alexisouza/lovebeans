// Fun��o usada para inicializa��o, chamada no in�cio da execu��o do jogo
function love.load()
    
end

// Fun��o usada para atualizar o estado do jogo, chamada a cada frame
function love.update(dt)

end

// Fun��o usada para desenhar na tela, chamada a cada frama
function love.draw()

end